# Antistatic Translations

Contains translation FTL files used in Antistatic. FTL is a Fluent Translation List: https://github.com/projectfluent/fluent
