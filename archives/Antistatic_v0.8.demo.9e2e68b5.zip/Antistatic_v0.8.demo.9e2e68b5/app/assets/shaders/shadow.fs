#version 400

void main(void) {
}
